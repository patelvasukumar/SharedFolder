/*
 * Student Name: Stanley Pieda
 * Lab Professor: Stanley Pieda
 * Due Date: Nov 6, 2020 by 11:59pm
 * Modified: Nov 6, 2020 by 11:59pm
 * Modified By: David Haley, 17 Oct 2024
 * Description: Sample solution for Pre-Lab Exercise 04, 2024 Fall
 */


import java.util.Scanner;

/* 
 * Simple class, contains main line logic for application.
 */
public class Driver {

	/*
	 * Entry point for the application
	 */
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		GradingSystem gradingSystem = null;
		String course = null;
		String grade = null;
		String report = null;

		System.out.print("Please enter course number ");
		course = keyboard.nextLine();

		System.out.print("Please enter letter grade ");
		grade = keyboard.nextLine();
		
		gradingSystem = new GradingSystem(course, grade);
		
		report = gradingSystem.createReport();		
		System.out.println(report);
		
		//System.out.println("Program by Your Name Here");
		System.out.println("Program by David Haley");
		System.out.println();

	}
}



