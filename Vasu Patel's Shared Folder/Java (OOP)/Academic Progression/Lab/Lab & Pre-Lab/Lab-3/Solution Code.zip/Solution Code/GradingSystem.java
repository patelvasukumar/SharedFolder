/*
 * Student Name: Stanley Pieda
 * Lab Professor: Stanley Pieda
 * Due Date: Nov 13, 2020 by 11:59pm
 * Modified: Oct 27, 2020 by 11:59pm
 * Modified By: Stanley Pieda
 * Modified By: David Haley, 17 Oct 2024
 * Description: Sample solution for Pre-Lab Ex 04, 2023 Fall
 */

/*
 * Reference:
 * Percent Grade	Letter Grade	Numeric Grade
 * 80 - 100			A				4.0
 * 70 - 79			B				3.0
 * 60 - 69			C				2.0
 * 50 - 59			D				1.0
 * 0 - 49			F				0.0
 * 
 * Special Case: One of the courses at the school, ABC333, has a requirement
 * that if a student obtains a grade of D it is treated as an F. 
 */

/* 
 * Abstracts a grading system.
 */
public class GradingSystem {
	private String courseName;
	private String letterGrade;

	/*
	 * Default constructor, sets course name to "Not specified" and letterGrade
	 * to "F"
	 */
	public GradingSystem() {
		this("Not specified", "F");
	}

	/*
	 * Overloaded constructor, courseName and letterGrade
	 */
	public GradingSystem(String courseName, String letterGrade) {
		setCourseName(courseName);
		setLetterGrade(letterGrade);
	}

	/*
	 * Accessor for courseName
	 */
	public String getCourseName() {
		return courseName;
	}

	/*
	 * Mutator for courseName
	 */
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	/*
	 * Accessor for letterGrade
	 */
	public String getLetterGrade() {
		return letterGrade;
	}

	/*
	 * Mutator for letterGrade
	 */
	public void setLetterGrade(String letterGrade) {
		this.letterGrade = letterGrade;
	}

	/*
	 * Uses decisions to generate a report based on the letter grade in memory,
	 * The course name is followed by the percent range, the letter grade, and 
	 * numeric grade. For example Course ABC333 with letter grade A produces:
	 * "Course ABC333: Entered Grade A, Percent Grade 80 - 100, Number Grade 4.0" 
	 */
	public String createReport() {
		String report = null;
		// constants could be used for the letter grades, but 
		// switch(letterGrade) with case "A" etc. should be understandable.
		switch(letterGrade) {
		case "A":
			report = "Course " + courseName + 
            ": Entered Grade A, Percent Grade 80 - 100, Number Grade 4.0";
			break;
		case "B":
			report = "Course " + courseName + 
            ": Entered Grade B, Percent Grade 70 - 79, Number Grade 3.0";
			break;
		case "C":
			report = "Course " + courseName + 
            ": Entered Grade C, Percent Grade 60 - 69, Number Grade 2.0";
			break;
		case "D":
			if(courseName.equals("ABC333")) {
				report = "Course " + courseName + 
                        ": Entered Grade D, Actual Grade F, " +
						"Percent Grade 0 - 49, Number Grade 0.0";
			}
			else {
				report = "Course " + courseName + 
                        ": Entered Grade D, Percent Grade 50 - 59, " + 
						"Number Grade 1.0";
			}
			break;
		case "F":
			report = "Course " + courseName + 
            ": Entered Grade F, Percent Grade 0 - 49, Number Grade 0.0";
		break;
		default:
			report = "Invalid letter grade entered";
			break;
		}
        return report;
	}


}