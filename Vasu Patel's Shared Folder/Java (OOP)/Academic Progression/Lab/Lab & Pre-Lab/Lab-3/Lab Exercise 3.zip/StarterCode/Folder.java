public class Folder {
    private String folderID;
    private String name;
    private String location;
    private int numberOfFiles;

    //TODO add a default no-argument and an overloaded constructor

    //TODO add getter and setter methods for all attributes  

    //TODO create method to increase and decrease number of files by 1

    public void decreaseNumberOfFiles() {
        //TODO change the value of numberOfFiles instance variable (assume it is always positive)
    }

    public void increaseNumberOfFiles() {
        //TODO change the value of numberOfFiles instance variable
    }

    public String toString() {
        //TODO Implement the toString() method here
    }

}
