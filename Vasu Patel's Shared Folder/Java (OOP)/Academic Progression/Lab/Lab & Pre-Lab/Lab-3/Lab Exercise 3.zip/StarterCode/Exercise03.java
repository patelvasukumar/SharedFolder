import java.util.Scanner;

public class Exercise03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //TODO Ask the user to input details for folder1 (folderID, name, location and number of files)
       
        //TODO Instantiate folder1 object using these details provided and the overloaded constructor that accepts these details
        
        //TODO Ask the user to input details for folder2 (folderID, name, location and number of files)
        
        //TODO Instantiate folder2 object using the no-argument constructor

		//TODO Use the setter methods to set the details of folder2

        //TODO Display folde1 details in a sentence using the getter methods
       
        //TODO Display folder2 details in a sentence using the toString() method
       
        //TODO Demonstrate increase number of files for folder1 by calling its increaseNumberOfFiles() method
       
        //TODO Print the numberOfFiles for folder1 after previous operation 
        
        //TODO Demonstrate decrease number of files for folder1 by calling its decreaseNumberOfFiles() method
        
        //TODO Print the numberOfFiles for folder1 after previous operation 
 
        //TODO Close the scanner object and print your name to the console
     
    }
}
